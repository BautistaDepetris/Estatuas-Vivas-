/* global React, PV2, PaintingPh, EditorialNum, HrBrown, ScriptHeader, StatusBarLight, Butterfly */

// ============================================================
// ESTATUA — Cura Brochero (la pantalla más importante)
// ============================================================
function EstatuaV2() {
  const capitulos = [
    { n: 'I',   t: 'Sus Orígenes',
      d: 'José Gabriel Brochero nació el 16 de marzo de 1840 en Santa Rosa de Río Primero. Desde joven sintió el llamado del sacerdocio con una claridad que contrastaba con la comodidad que su familia podría haberle ofrecido.' },
    { n: 'II',  t: 'Los Caminos de las Sierras',
      d: 'A lomo de mula recorrió durante décadas los laberintos de las sierras cordobesas. Construyó capillas donde no había refugio, acequias donde no había agua, y escuelas donde no había futuro.' },
    { n: 'III', t: 'El Hombre del Pueblo',
      d: 'Brochero no hablaba desde el púlpito hacia abajo: hablaba de igual a igual, con el vocabulario del trabajador. Cuando la lepra empezó a diezmar a su gente, no huyó. Se quedó.' },
    { n: 'IV',  t: 'Su Legado',
      d: 'El 16 de octubre de 2016 el Papa Francisco lo canonizó en la Plaza de San Pedro. Su estatua en Villa San Lorenzo es hoy un punto de peregrinación silenciosa.' },
  ];

  return (
    <div style={{ width: '100%', background: PV2.bg, color: PV2.ink, fontFamily: PV2.sans }}>

      {/* ───────── HERO con video placeholder ───────── */}
      <section style={{ position: 'relative', height: 720 }}>
        {/* big painting hero */}
        <PaintingPh height={720} tone="portrait" label={null} style={{ position: 'absolute', inset: 0 }}/>
        {/* cream fade overlay bottom 50% */}
        <div style={{
          position: 'absolute', left: 0, right: 0, bottom: 0, height: '55%',
          background: `linear-gradient(180deg, transparent 0%, ${PV2.bg} 90%)`,
          pointerEvents: 'none',
        }}/>

        <StatusBarLight/>

        {/* close X top right */}
        <button data-go="home" style={{
          position: 'absolute', top: 50, right: 22, zIndex: 5,
          width: 36, height: 36, background: 'rgba(245,237,216,0.85)',
          backdropFilter: 'blur(8px)', border: `0.5px solid ${PV2.border}`,
          color: PV2.brown, cursor: 'pointer',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M18 6 6 18M6 6l12 12"/>
          </svg>
        </button>

        {/* video placeholder marker centered */}
        <div style={{
          position: 'absolute', top: '34%', left: '50%',
          transform: 'translate(-50%, -50%)', textAlign: 'center',
          padding: '14px 20px',
          border: `0.5px dashed ${PV2.red}`,
          background: 'rgba(245,237,216,0.55)',
        }}>
          <div style={{ fontFamily: PV2.sans, fontSize: 8, fontWeight: 500,
            letterSpacing: '0.32em', textTransform: 'uppercase',
            color: PV2.red }}>[ Video — Cura Brochero ]</div>
        </div>

        {/* hero content bottom-left */}
        <div style={{
          position: 'absolute', left: 26, right: 26, bottom: 32, zIndex: 5,
        }}>
          <div style={{ fontFamily: PV2.sans, fontSize: 9, fontWeight: 500,
            letterSpacing: '0.28em', textTransform: 'uppercase',
            color: PV2.brown, marginBottom: 14 }}>
            Santo de los Caminos
          </div>
          <h1 style={{
            fontFamily: PV2.serif, fontStyle: 'italic', fontWeight: 400,
            fontSize: 64, lineHeight: 0.9, letterSpacing: '-0.025em',
            color: PV2.red, margin: 0,
          }}>Cura<br/>Brochero</h1>
          <div style={{ marginTop: 16, fontFamily: PV2.sans, fontSize: 10,
            letterSpacing: '0.18em', color: PV2.brown,
            textTransform: 'uppercase' }}>
            1840 — 1914 &middot; Santa Rosa, Córdoba
          </div>
        </div>

        {/* butterfly */}
        <div style={{ position: 'absolute', top: 130, left: 28, zIndex: 4 }}>
          <Butterfly size={18} color={PV2.red}/>
        </div>
      </section>

      {/* ───────── /01 SU HISTORIA ───────── */}
      <section style={{ padding: '56px 0 48px', background: PV2.bg }}
        className="paper-bg">
        <div style={{ padding: '0 26px 0' }}>
          <EditorialNum num="01" label="Su Historia"/>
          <HrBrown style={{ margin: '12px 0 24px' }}/>
          <ScriptHeader size={30}>Cuatro capítulos<br/>de una vida.</ScriptHeader>
        </div>

        <div style={{ display: 'flex', gap: 14, padding: '32px 26px 0',
          overflowX: 'auto' }} className="scroll-x">
          {capitulos.map((c, i) => (
            <article key={i} style={{
              minWidth: 240, maxWidth: 240,
              background: PV2.bg2, border: `0.5px solid ${PV2.border}`,
              padding: '22px 22px 24px',
              display: 'flex', flexDirection: 'column', gap: 12,
            }}>
              <div style={{ fontFamily: PV2.serif, fontStyle: 'italic',
                fontSize: 14, color: PV2.red, fontWeight: 400 }}>/{c.n}</div>
              <h3 style={{ fontFamily: PV2.serif, fontStyle: 'italic',
                fontSize: 18, lineHeight: 1.15, color: PV2.ink,
                margin: 0, fontWeight: 400, letterSpacing: '-0.01em' }}>{c.t}</h3>
              <p style={{ fontFamily: PV2.sans, fontSize: 11, lineHeight: 1.75,
                color: PV2.ink3, margin: 0 }}>{c.d}</p>
            </article>
          ))}
        </div>

        {/* dot indicator */}
        <div style={{ display: 'flex', gap: 6, justifyContent: 'center', marginTop: 24 }}>
          {capitulos.map((_, i) => (
            <span key={i} style={{ width: i === 0 ? 16 : 4, height: 1.5,
              background: i === 0 ? PV2.red : PV2.border }}/>
          ))}
        </div>
      </section>

      {/* ───────── /02 FRASE DESTACADA ───────── */}
      <section style={{
        padding: '72px 26px', background: PV2.bg2,
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 24,
        position: 'relative',
      }}>
        <span style={{
          fontFamily: PV2.serif, fontSize: 92, color: PV2.red,
          opacity: 0.18, lineHeight: 0.6, marginBottom: -10,
        }}>"</span>
        <HrBrown width={50} color={PV2.borderDark}/>
        <p style={{
          fontFamily: PV2.serif, fontStyle: 'italic',
          fontSize: 22, lineHeight: 1.35, color: PV2.ink,
          textAlign: 'center', margin: 0, maxWidth: 280, fontWeight: 400,
        }}>La religión no se predica,<br/>se vive.</p>
        <HrBrown width={50} color={PV2.borderDark}/>
        <div style={{ fontFamily: PV2.sans, fontSize: 8,
          letterSpacing: '0.32em', textTransform: 'uppercase',
          color: PV2.brown, fontWeight: 500 }}>
          — Cura Brochero
        </div>
        <Butterfly size={16} color={PV2.brown} style={{ position: 'absolute', top: 28, right: 36 }}/>
      </section>

      {/* ───────── /03 GALERÍA ───────── */}
      <section style={{ padding: '56px 0 48px', background: PV2.bg }}
        className="paper-bg">
        <div style={{ padding: '0 26px' }}>
          <EditorialNum num="03" label="Galería"/>
          <HrBrown style={{ margin: '12px 0 22px' }}/>
          <ScriptHeader size={28}>Su vida en archivo.</ScriptHeader>
        </div>
        <div style={{ display: 'flex', gap: 12, padding: '28px 26px 0',
          overflowX: 'auto' }} className="scroll-x">
          {[
            { lbl: 'Paisaje · 1923',   t: 'Sierras al Atardecer', d: 'Las sierras que Brochero recorrió a lomo de mula.', tone: 'sepia' },
            { lbl: 'Naturaleza',        t: 'Caminos de Altura',     d: 'Senderos de montaña por donde llevaba la fe.', tone: 'pastoral' },
            { lbl: 'Paisaje · 1908',    t: 'Cielo Cordobés',        d: 'Testigo silencioso de sus travesías.', tone: 'sky' },
            { lbl: 'Patrimonio',        t: 'Sendero de las Sierras', d: 'Camino rural como los que transitó.', tone: 'sepia' },
          ].map((g, i) => (
            <div key={i} style={{ minWidth: 220, maxWidth: 220 }}>
              <div style={{
                padding: 5,
                background: 'linear-gradient(135deg, #d9bf8a, #8c6b42)',
                border: '0.5px solid #6b4c2a',
              }}>
                <PaintingPh height={270} tone={g.tone} label={null}/>
              </div>
              <div style={{ paddingTop: 12 }}>
                <div style={{ fontFamily: PV2.sans, fontSize: 7, fontWeight: 500,
                  letterSpacing: '0.28em', textTransform: 'uppercase',
                  color: PV2.brown, marginBottom: 6 }}>{g.lbl}</div>
                <div style={{ fontFamily: PV2.serif, fontStyle: 'italic',
                  fontSize: 14, color: PV2.ink, marginBottom: 4 }}>{g.t}</div>
                <div style={{ fontFamily: PV2.sans, fontSize: 10,
                  color: PV2.ink3, lineHeight: 1.55 }}>{g.d}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ───────── /04 EL PUEBLO RECOMIENDA ───────── */}
      <section style={{ padding: '56px 26px 48px', background: PV2.bg2,
        position: 'relative' }}>
        <EditorialNum num="04" label="El Pueblo Recomienda"/>
        <HrBrown color={PV2.borderDark} style={{ margin: '12px 0 22px' }}/>
        <p style={{ fontFamily: PV2.serif, fontStyle: 'italic',
          fontSize: 18, lineHeight: 1.4, color: PV2.ink2,
          margin: '0 0 28px', maxWidth: 280 }}>
          "Si querés conocer mis pasos, te dejo estos lugares —"
        </p>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {[
            { cat: 'Patrimonio Religioso', t: 'Capilla Brochero',
              d: 'El recinto donde ofició sus últimas misas. Patrimonio histórico provincial desde 1983.', tone: 'sepia' },
            { cat: 'Naturaleza', t: 'Sendero de las Sierras',
              d: 'El camino que Brochero recorrió. Hoy abierto al turismo espiritual.', tone: 'pastoral' },
          ].map((p, i) => (
            <div key={i} data-go="lugares" style={{
              display: 'flex', gap: 14, alignItems: 'flex-start',
              padding: '18px 0',
              borderBottom: i === 0 ? `0.5px solid ${PV2.border}` : 'none',
              cursor: 'pointer',
            }}>
              <div style={{ padding: 3,
                background: 'linear-gradient(135deg, #d9bf8a, #8c6b42)',
                border: '0.5px solid #6b4c2a' }}>
                <PaintingPh width={56} height={56} tone={p.tone} label={null}/>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: PV2.sans, fontSize: 7,
                  letterSpacing: '0.28em', textTransform: 'uppercase',
                  color: PV2.brown, marginBottom: 4 }}>{p.cat}</div>
                <div style={{ fontFamily: PV2.serif, fontStyle: 'italic',
                  fontSize: 15, color: PV2.ink, marginBottom: 4 }}>{p.t}</div>
                <div style={{ fontFamily: PV2.sans, fontSize: 10,
                  color: PV2.ink3, lineHeight: 1.55 }}>{p.d}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ───────── /05 SIGUIENTE ESTATUA ───────── */}
      <section style={{ position: 'relative', height: 200 }}>
        <PaintingPh height={200} tone="ember" label={null} style={{ position: 'absolute', inset: 0 }}/>
        <div style={{ position: 'absolute', inset: 0,
          background: `linear-gradient(180deg, rgba(245,237,216,0.5) 0%, rgba(245,237,216,0.85) 100%)` }}/>
        <div style={{ position: 'absolute', left: 26, right: 26,
          top: 0, bottom: 0, display: 'flex', flexDirection: 'column',
          justifyContent: 'center', zIndex: 5 }}>
          <div style={{ fontFamily: PV2.sans, fontSize: 9, fontWeight: 500,
            letterSpacing: '0.28em', textTransform: 'uppercase',
            color: PV2.brown, marginBottom: 10 }}>
            Continuá el recorrido
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline',
            justifyContent: 'space-between' }}>
            <div style={{ fontFamily: PV2.serif, fontStyle: 'italic',
              fontSize: 32, color: PV2.red, lineHeight: 1,
              letterSpacing: '-0.02em' }}>San Lorenzo</div>
            <span style={{ color: PV2.red, fontSize: 22 }}>→</span>
          </div>
          <div style={{ marginTop: 8, fontFamily: PV2.sans, fontSize: 10,
            color: PV2.ink3, letterSpacing: '0.05em' }}>
            320 m &middot; Plaza Central
          </div>
        </div>
      </section>

      {/* spacer */}
      <div style={{ height: 80, background: PV2.bg }}/>

      {/* ───────── AUDIO PLAYER FLOTANTE ───────── */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        height: 64, background: PV2.bg2,
        borderTop: `1px solid ${PV2.red}`,
        padding: '0 18px', display: 'flex', alignItems: 'center', gap: 14,
        zIndex: 50,
      }}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={PV2.red}
          strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M9 18V5l12-2v13"/>
          <circle cx="6" cy="18" r="3"/>
          <circle cx="18" cy="16" r="3"/>
        </svg>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between',
            fontFamily: PV2.sans, fontSize: 9, letterSpacing: '0.18em',
            textTransform: 'uppercase', color: PV2.ink, marginBottom: 6 }}>
            <span>Brochero &middot; Cap. I</span>
            <span style={{ color: PV2.ink4 }}>02:14 / 06:30</span>
          </div>
          <div style={{ height: 1, background: PV2.border, position: 'relative' }}>
            <div style={{ position: 'absolute', inset: 0, width: '35%',
              background: PV2.red }}/>
          </div>
        </div>
        <button style={{
          width: 38, height: 38, borderRadius: '50%', background: PV2.red,
          border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: PV2.paper, cursor: 'pointer',
        }}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
            <path d="M8 5v14l11-7z"/>
          </svg>
        </button>
      </div>
    </div>
  );
}

window.EstatuaV2 = EstatuaV2;
