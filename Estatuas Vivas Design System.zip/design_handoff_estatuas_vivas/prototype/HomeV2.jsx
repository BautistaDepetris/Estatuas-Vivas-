/* global React, PV2, PaintingPh, FramedPainting, EditorialNum, HrBrown,
          ScriptHeader, StatusBarLight, Butterfly */

// ============================================================
// HOME — Villa San Lorenzo
// ============================================================
function HomeV2() {
  return (
    <div style={{ width: '100%', background: PV2.bg, color: PV2.ink, fontFamily: PV2.sans }}>

      {/* ───────── HERO ───────── */}
      <section style={{ position: 'relative', paddingBottom: 56 }}
        className="paper-bg">
        <StatusBarLight/>
        {/* top: wordmark + small image, à la "The Museum." */}
        <div style={{ padding: '18px 26px 0', display: 'flex',
          justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontFamily: PV2.serif, fontStyle: 'italic',
            fontSize: 14, color: PV2.red, letterSpacing: '0.02em' }}>
            Villa San Lorenzo
          </div>
          <div style={{ display: 'inline-flex', gap: 3, alignItems: 'center' }}>
            <span style={{ width: 3, height: 3, background: PV2.red }}/>
            <span style={{ width: 3, height: 3, background: PV2.red }}/>
            <span style={{ width: 3, height: 3, background: PV2.red }}/>
          </div>
        </div>

        {/* Big title with painting inset, like "The Museum." reference */}
        <div style={{ padding: '36px 26px 0', position: 'relative' }}>
          <h1 style={{
            fontFamily: PV2.serif, fontStyle: 'italic', fontWeight: 400,
            fontSize: 62, lineHeight: 0.92, letterSpacing: '-0.025em',
            color: PV2.ink, margin: 0,
          }}>Las<br/>Estatuas<br/>Cobran</h1>
          {/* small inset painting next to "Cobran" / before "Vida" */}
          <div style={{ display: 'flex', alignItems: 'flex-end',
            gap: 14, marginTop: 4 }}>
            <div style={{
              padding: 4,
              background: 'linear-gradient(135deg, #d9bf8a, #8c6b42)',
              border: '0.5px solid #6b4c2a',
            }}>
              <PaintingPh width={72} height={54} tone="portrait" label={null}/>
            </div>
            <h1 style={{
              fontFamily: PV2.serif, fontStyle: 'italic', fontWeight: 400,
              fontSize: 62, lineHeight: 0.92, letterSpacing: '-0.025em',
              color: PV2.ink, margin: 0,
            }}>Vida.</h1>
          </div>
          <div style={{ marginTop: 18, fontFamily: PV2.sans, fontSize: 9,
            letterSpacing: '0.28em', textTransform: 'uppercase',
            color: PV2.brown, fontWeight: 500 }}>
            Patrimonio Cultural &middot; Córdoba, Argentina
          </div>
        </div>

        {/* Frase corta */}
        <div style={{ padding: '36px 26px 0' }}>
          <p style={{ fontFamily: PV2.serif, fontStyle: 'italic',
            fontSize: 15, lineHeight: 1.5, color: PV2.ink2,
            margin: 0, maxWidth: 280 }}>
            Acercate a una estatua del pueblo, escaneá su QR, y dejala que te cuente.
          </p>
        </div>

        {/* CTA */}
        <div style={{ padding: '32px 26px 0' }}>
          <button className="btn-red" data-go="estatua">
            Explorar el pueblo <span>→</span>
          </button>
        </div>

        {/* Butterfly decoration */}
        <div style={{ position: 'absolute', top: 110, right: 28 }}>
          <Butterfly size={22} color={PV2.brown}/>
        </div>
      </section>

      {/* ───────── /01 LAS ESTATUAS ───────── */}
      <section style={{ padding: '40px 26px 56px', background: PV2.bg }}
        className="paper-bg">
        <div style={{ marginBottom: 8 }}>
          <EditorialNum num="01" label="Las Estatuas"/>
        </div>
        <HrBrown style={{ marginBottom: 28 }}/>

        <ScriptHeader size={36}>Dos figuras,<br/>dos siglos.</ScriptHeader>

        <div style={{ marginTop: 36, display: 'flex', flexDirection: 'column', gap: 36 }}>
          {/* Card 1 — Cura Brochero */}
          <article data-go="estatua">
            <div style={{
              padding: 6,
              background: 'linear-gradient(135deg, #d9bf8a, #b89c64 60%, #8c6b42)',
              border: '0.5px solid #6b4c2a',
            }}>
              <PaintingPh height={240} tone="portrait" label="Brochero · óleo 1908"/>
            </div>
            <div style={{ padding: '18px 0 0' }}>
              <div style={{ fontFamily: PV2.sans, fontSize: 9, fontWeight: 500,
                letterSpacing: '0.28em', textTransform: 'uppercase',
                color: PV2.brown, marginBottom: 10 }}>
                Santo de los Caminos
              </div>
              <h3 style={{ fontFamily: PV2.serif, fontStyle: 'italic',
                fontSize: 30, fontWeight: 400, color: PV2.red,
                margin: '0 0 10px', lineHeight: 1, letterSpacing: '-0.02em' }}>
                Cura Brochero
              </h3>
              <p style={{ fontFamily: PV2.sans, fontSize: 11, lineHeight: 1.75,
                color: PV2.ink3, margin: 0, maxWidth: '34ch' }}>
                Recorrió las sierras a lomo de mula durante décadas. Construyó
                capillas, acequias y escuelas donde no había futuro.
              </p>
              <div style={{ marginTop: 16, fontFamily: PV2.sans, fontSize: 10,
                fontWeight: 500, letterSpacing: '0.22em', textTransform: 'uppercase',
                color: PV2.red, display: 'inline-flex', gap: 10, alignItems: 'center' }}>
                Descubrir <span style={{ fontSize: 14 }}>→</span>
              </div>
            </div>
          </article>

          {/* Card 2 — San Lorenzo */}
          <article data-go="estatua">
            <div style={{
              padding: 6,
              background: 'linear-gradient(135deg, #d9bf8a, #b89c64 60%, #8c6b42)',
              border: '0.5px solid #6b4c2a',
            }}>
              <PaintingPh height={240} tone="ember" label="San Lorenzo · siglo III"/>
            </div>
            <div style={{ padding: '18px 0 0' }}>
              <div style={{ fontFamily: PV2.sans, fontSize: 9, fontWeight: 500,
                letterSpacing: '0.28em', textTransform: 'uppercase',
                color: PV2.brown, marginBottom: 10 }}>
                Patrono del Pueblo
              </div>
              <h3 style={{ fontFamily: PV2.serif, fontStyle: 'italic',
                fontSize: 30, fontWeight: 400, color: PV2.red,
                margin: '0 0 10px', lineHeight: 1, letterSpacing: '-0.02em' }}>
                San Lorenzo
              </h3>
              <p style={{ fontFamily: PV2.sans, fontSize: 11, lineHeight: 1.75,
                color: PV2.ink3, margin: 0, maxWidth: '34ch' }}>
                Diácono romano, mártir del siglo III. Dador de los bienes de la
                iglesia a los pobres antes de su martirio.
              </p>
              <div style={{ marginTop: 16, fontFamily: PV2.sans, fontSize: 10,
                fontWeight: 500, letterSpacing: '0.22em', textTransform: 'uppercase',
                color: PV2.red, display: 'inline-flex', gap: 10, alignItems: 'center' }}>
                Descubrir <span style={{ fontSize: 14 }}>→</span>
              </div>
            </div>
          </article>
        </div>
      </section>

      {/* ───────── /02 GALERÍA HISTÓRICA ───────── */}
      <section style={{ padding: '48px 26px 56px', background: PV2.bg2 }}>
        <div style={{ marginBottom: 8 }}>
          <EditorialNum num="02" label="Galería Histórica"/>
        </div>
        <HrBrown color={PV2.borderDark} style={{ marginBottom: 22 }}/>

        <p style={{ fontFamily: PV2.serif, fontStyle: 'italic',
          fontSize: 15, lineHeight: 1.5, color: PV2.ink2,
          margin: '0 0 28px', maxWidth: 280 }}>
          Cuarenta y dos imágenes del archivo del pueblo, datadas entre 1908 y 1956.
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 26 }}>
          {[
            { tone: 'sepia',    cat: 'Paisaje',     t: 'Sierras al Atardecer' },
            { tone: 'pastoral', cat: 'Naturaleza',  t: 'Caminos de Altura' },
            { tone: 'sky',      cat: 'Patrimonio',  t: 'Cielo Cordobés' },
            { tone: 'portrait', cat: 'Devoción',    t: 'Luz de Velas' },
          ].map((g, i) => (
            <div key={i}>
              <div style={{
                padding: 4,
                background: 'linear-gradient(135deg, #d9bf8a, #8c6b42)',
                border: '0.5px solid #6b4c2a',
              }}>
                <PaintingPh height={140} tone={g.tone} label={null}/>
              </div>
              <div style={{ paddingTop: 10 }}>
                <div style={{ fontFamily: PV2.sans, fontSize: 7, fontWeight: 500,
                  letterSpacing: '0.28em', textTransform: 'uppercase', color: PV2.brown }}>
                  {g.cat}
                </div>
                <div style={{ fontFamily: PV2.serif, fontStyle: 'italic',
                  fontSize: 13, color: PV2.ink, marginTop: 4, lineHeight: 1.15 }}>
                  {g.t}
                </div>
              </div>
            </div>
          ))}
        </div>

        <button className="btn-outline-red" data-go="galeria">
          Ver galería completa <span>→</span>
        </button>
      </section>

      {/* ───────── /03 LUGARES ───────── */}
      <section style={{ padding: '48px 26px 56px', background: PV2.bg }}
        className="paper-bg" data-go-section="lugares">
        <div style={{ marginBottom: 8 }}>
          <EditorialNum num="03" label="Lugares para Conocer"/>
        </div>
        <HrBrown style={{ marginBottom: 28 }}/>

        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {[
            { cat: 'Patrimonio Religioso', t: 'Capilla Brochero',
              d: 'El recinto donde ofició sus últimas misas.' },
            { cat: 'Patrimonio Religioso', t: 'Iglesia San Lorenzo',
              d: 'Epicentro de la devoción desde 1887.' },
            { cat: 'Espacio Público',       t: 'Plaza Central',
              d: 'El corazón cívico del pueblo desde su fundación.' },
            { cat: 'Naturaleza',            t: 'Sendero de las Sierras',
              d: 'El camino que Brochero recorrió innumerables veces.' },
          ].map((p, i) => (
            <div key={i} data-go="lugares" style={{
              display: 'flex', gap: 14, alignItems: 'flex-start',
              padding: '16px 0',
              borderBottom: i < 3 ? `0.5px solid ${PV2.border}` : 'none',
              cursor: 'pointer',
            }}>
              <div style={{ padding: 3,
                background: 'linear-gradient(135deg, #d9bf8a, #8c6b42)',
                border: '0.5px solid #6b4c2a', flexShrink: 0 }}>
                <PaintingPh width={62} height={62} tone={['sepia','ember','sky','pastoral'][i]} label={null}/>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: PV2.sans, fontSize: 7,
                  letterSpacing: '0.25em', textTransform: 'uppercase',
                  color: PV2.brown, marginBottom: 4 }}>{p.cat}</div>
                <div style={{ fontFamily: PV2.serif, fontStyle: 'italic',
                  fontSize: 16, color: PV2.ink, marginBottom: 4,
                  lineHeight: 1.1 }}>{p.t}</div>
                <div style={{ fontFamily: PV2.sans, fontSize: 10,
                  color: PV2.ink3, lineHeight: 1.5 }}>{p.d}</div>
              </div>
              <span style={{ color: PV2.red, fontSize: 14, marginTop: 4 }}>→</span>
            </div>
          ))}
        </div>
      </section>

      {/* ───────── FOOTER ───────── */}
      <footer style={{ padding: '40px 26px 32px', background: PV2.bg }}
        className="paper-bg">
        <HrBrown color={PV2.borderDark} style={{ marginBottom: 26 }}/>
        <div style={{ fontFamily: PV2.serif, fontStyle: 'italic',
          fontSize: 30, color: PV2.red, marginBottom: 6,
          letterSpacing: '-0.02em' }}>Villa San Lorenzo</div>
        <div style={{ fontFamily: PV2.sans, fontSize: 9,
          letterSpacing: '0.22em', color: PV2.brown,
          textTransform: 'uppercase', marginBottom: 28 }}>
          Patrimonio Cultural Digital &middot; Córdoba
        </div>
        <div style={{ display: 'flex', gap: 16, fontFamily: PV2.sans,
          fontSize: 8, letterSpacing: '0.28em', color: PV2.ink4,
          textTransform: 'uppercase' }}>
          <a data-go="estatua">Estatuas</a>
          <a data-go="galeria">Galería</a>
          <a data-go="lugares">Lugares</a>
          <a data-go="admin">Admin</a>
        </div>
        <div style={{ marginTop: 24, fontFamily: PV2.serif, fontStyle: 'italic',
          fontSize: 10, color: PV2.ink4, lineHeight: 1.7 }}>
          © 2026 — Una iniciativa del Municipio de Villa San Lorenzo.
        </div>
      </footer>
    </div>
  );
}

window.HomeV2 = HomeV2;
