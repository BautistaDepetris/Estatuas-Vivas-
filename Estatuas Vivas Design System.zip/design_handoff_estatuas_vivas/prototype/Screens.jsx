/* global React, PV2, PaintingPh, EditorialNum, HrBrown, ScriptHeader, StatusBarLight, Butterfly */

// ============================================================
// GALERÍA COMPLETA
// ============================================================
function GaleriaV2() {
  const items = [
    { lbl: 'Paisaje · 1923',    t: 'Sierras al Atardecer', d: 'Hora dorada en las sierras cordobesas.', tone: 'sepia',    h: 250 },
    { lbl: 'Naturaleza',         t: 'Caminos de Altura',     d: 'Senderos de montaña.', tone: 'pastoral', h: 190 },
    { lbl: 'Patrimonio',         t: 'Arquitectura Colonial', d: 'La traza original del pueblo.', tone: 'portrait', h: 210 },
    { lbl: 'Paisaje · 1908',     t: 'Cielo Cordobés',        d: 'Testigo silencioso de las travesías.', tone: 'sky', h: 290 },
    { lbl: 'Devoción',           t: 'Luz de Velas',          d: 'Devoción popular al mártir romano.', tone: 'ember', h: 210 },
    { lbl: 'Naturaleza',         t: 'Cielo Dramático',       d: 'Cielos abiertos de la región.', tone: 'sky', h: 250 },
    { lbl: 'Historia',           t: 'Piedra Antigua',        d: 'La Roma del siglo III, evocada en piedra.', tone: 'sepia', h: 190 },
    { lbl: 'Patrimonio',         t: 'Bautismo',              d: 'Familias del pueblo, pila bautismal antigua.', tone: 'portrait', h: 230 },
  ];
  const col1 = items.filter((_, i) => i % 2 === 0);
  const col2 = items.filter((_, i) => i % 2 === 1);

  const Card = ({ it }) => (
    <article style={{ marginBottom: 26 }}>
      <div style={{
        padding: 5,
        background: 'linear-gradient(135deg, #d9bf8a, #8c6b42)',
        border: '0.5px solid #6b4c2a',
      }}>
        <PaintingPh height={it.h} tone={it.tone} label={null}/>
      </div>
      <div style={{ paddingTop: 10 }}>
        <div style={{ fontFamily: PV2.sans, fontSize: 7, fontWeight: 500,
          letterSpacing: '0.28em', textTransform: 'uppercase', color: PV2.brown,
          marginBottom: 6 }}>{it.lbl}</div>
        <div style={{ fontFamily: PV2.serif, fontStyle: 'italic',
          fontSize: 15, color: PV2.ink, marginBottom: 4, lineHeight: 1.15 }}>{it.t}</div>
        <div style={{ fontFamily: PV2.sans, fontSize: 10,
          color: PV2.ink3, lineHeight: 1.55 }}>{it.d}</div>
      </div>
    </article>
  );

  return (
    <div style={{ width: '100%', background: PV2.bg, color: PV2.ink, fontFamily: PV2.sans }}>
      <section className="paper-bg" style={{ background: PV2.bg, paddingBottom: 24 }}>
        <StatusBarLight/>
        <div style={{ padding: '52px 26px 28px', position: 'relative' }}>
          <EditorialNum num="03" label="Archivo Histórico"/>
          <HrBrown style={{ margin: '12px 0 26px' }}/>
          <h1 style={{ fontFamily: PV2.serif, fontStyle: 'italic',
            fontSize: 56, fontWeight: 400, lineHeight: 0.92,
            letterSpacing: '-0.025em', color: PV2.ink, margin: 0 }}>
            Galería<br/>Histórica.
          </h1>
          <p style={{ marginTop: 18, fontFamily: PV2.sans, fontSize: 11,
            lineHeight: 1.7, color: PV2.ink3, maxWidth: 280 }}>
            Cuarenta y dos imágenes del archivo del pueblo. Fotografías, estampas y
            documentos, casi todas en blanco y negro, todas con su procedencia.
          </p>
          <Butterfly size={20} color={PV2.brown} style={{ position: 'absolute', top: 40, right: 32 }}/>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 16,
          padding: '0 26px 14px', fontFamily: PV2.sans, fontSize: 8,
          letterSpacing: '0.28em', textTransform: 'uppercase', color: PV2.ink4 }}>
          <span style={{ color: PV2.red, paddingBottom: 4,
            borderBottom: `0.5px solid ${PV2.red}` }}>Todo</span>
          <span>Paisaje</span>
          <span>Patrimonio</span>
          <span>Devoción</span>
        </div>
        <HrBrown/>
      </section>

      <section style={{ padding: '28px 26px 48px', background: PV2.bg }}
        className="paper-bg">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <div>{col1.map((it, i) => <Card key={i} it={it}/>)}</div>
          <div style={{ paddingTop: 36 }}>{col2.map((it, i) => <Card key={i} it={it}/>)}</div>
        </div>
      </section>
    </div>
  );
}

window.GaleriaV2 = GaleriaV2;

// ============================================================
// LUGARES
// ============================================================
function LugaresV2() {
  const places = [
    { num: '01', cat: 'Espacio Público',         t: 'Plaza Central',
      d: 'El corazón cívico de Villa San Lorenzo desde su fundación. Lugar de encuentro y memoria.', tone: 'pastoral' },
    { num: '02', cat: 'Patrimonio Religioso',    t: 'Iglesia San Lorenzo',
      d: 'El edificio histórico del pueblo, epicentro de la devoción al mártir romano desde 1887.', tone: 'sepia' },
    { num: '03', cat: 'Patrimonio Religioso',    t: 'Capilla Brochero',
      d: 'El recinto donde ofició sus últimas misas. Patrimonio histórico provincial desde 1983.', tone: 'portrait' },
    { num: '04', cat: 'Naturaleza',              t: 'Sendero de las Sierras',
      d: 'El camino que Brochero recorrió innumerables veces. Hoy abierto al turismo espiritual.', tone: 'pastoral' },
  ];

  return (
    <div style={{ width: '100%', background: PV2.bg, color: PV2.ink, fontFamily: PV2.sans }}>
      <section className="paper-bg" style={{ background: PV2.bg }}>
        <StatusBarLight/>
        <div style={{ padding: '52px 26px 28px', position: 'relative' }}>
          <EditorialNum num="03" label="Lugares para Conocer"/>
          <HrBrown style={{ margin: '12px 0 26px' }}/>
          <h1 style={{ fontFamily: PV2.serif, fontStyle: 'italic',
            fontSize: 56, fontWeight: 400, lineHeight: 0.92,
            letterSpacing: '-0.025em', color: PV2.ink, margin: 0 }}>
            Lugares<br/>del pueblo.
          </h1>
          <p style={{ marginTop: 18, fontFamily: PV2.sans, fontSize: 11,
            lineHeight: 1.7, color: PV2.ink3, maxWidth: 280 }}>
            Lo que el pueblo camina, ordenado por cercanía a la plaza.
            Calzado cómodo y agua &mdash; el sol de Córdoba no perdona.
          </p>
          <Butterfly size={20} color={PV2.red} style={{ position: 'absolute', top: 40, right: 32 }}/>
        </div>
        <HrBrown style={{ margin: '0 26px' }}/>
      </section>

      <section style={{ padding: '32px 26px 48px', background: PV2.bg,
        display: 'flex', flexDirection: 'column', gap: 40 }}
        className="paper-bg">
        {places.map((p, i) => (
          <article key={i}>
            <div style={{
              padding: 6,
              background: 'linear-gradient(135deg, #d9bf8a, #8c6b42)',
              border: '0.5px solid #6b4c2a',
            }}>
              <PaintingPh height={180} tone={p.tone} label={null}/>
            </div>
            <div style={{ paddingTop: 20, display: 'flex',
              alignItems: 'flex-start', gap: 14 }}>
              <div style={{ fontFamily: PV2.serif, fontStyle: 'italic',
                fontSize: 18, color: PV2.red, fontWeight: 400,
                minWidth: 30 }}>/{p.num}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: PV2.sans, fontSize: 8, fontWeight: 500,
                  letterSpacing: '0.28em', textTransform: 'uppercase',
                  color: PV2.brown, marginBottom: 8 }}>{p.cat}</div>
                <h3 style={{ fontFamily: PV2.serif, fontStyle: 'italic',
                  fontSize: 22, color: PV2.ink, lineHeight: 1.1,
                  margin: '0 0 10px', fontWeight: 400, letterSpacing: '-0.01em' }}>
                  {p.t}
                </h3>
                <p style={{ fontFamily: PV2.sans, fontSize: 11, lineHeight: 1.7,
                  color: PV2.ink3, margin: 0 }}>{p.d}</p>
                <div style={{ marginTop: 14, fontFamily: PV2.sans, fontSize: 9,
                  fontWeight: 500, letterSpacing: '0.25em', textTransform: 'uppercase',
                  color: PV2.red, display: 'inline-flex', gap: 10,
                  alignItems: 'center' }}>
                  Cómo llegar <span style={{ fontSize: 14 }}>→</span>
                </div>
              </div>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}

window.LugaresV2 = LugaresV2;

// ============================================================
// ADMIN — desktop
// ============================================================
function AdminV2() {
  const navItems = [
    { lbl: 'Dashboard', active: true },
    { lbl: 'Estatuas',  active: false, count: '02' },
    { lbl: 'Galería',   active: false, count: '42' },
    { lbl: 'Lugares',   active: false, count: '04' },
  ];

  const sidebar = (
    <aside style={{
      width: 220, background: PV2.bg2, borderRight: `0.5px solid ${PV2.border}`,
      padding: '36px 0', display: 'flex', flexDirection: 'column',
      height: 760, position: 'absolute', left: 0, top: 0,
    }}>
      <div style={{ padding: '0 26px 36px' }}>
        <div style={{ fontFamily: PV2.serif, fontStyle: 'italic',
          fontSize: 22, color: PV2.red, letterSpacing: '-0.02em' }}>
          San Lorenzo
        </div>
        <div style={{ fontFamily: PV2.sans, fontSize: 8, letterSpacing: '0.28em',
          textTransform: 'uppercase', color: PV2.brown, marginTop: 6, fontWeight: 500 }}>
          Admin
        </div>
      </div>
      <nav style={{ display: 'flex', flexDirection: 'column' }}>
        {navItems.map((n, i) => (
          <a key={i} style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '14px 26px', cursor: 'pointer',
            fontFamily: PV2.sans, fontSize: 9, fontWeight: 500,
            letterSpacing: '0.28em', textTransform: 'uppercase',
            color: n.active ? PV2.red : PV2.brown,
            borderLeft: n.active ? `2px solid ${PV2.red}` : '2px solid transparent',
          }}>
            <span>{n.lbl}</span>
            {n.count && <span style={{ fontFamily: PV2.serif, fontSize: 12,
              fontStyle: 'italic', color: n.active ? PV2.red : PV2.ink4 }}>{n.count}</span>}
          </a>
        ))}
      </nav>
      <div style={{ marginTop: 'auto', padding: '24px 26px',
        fontFamily: PV2.sans, fontSize: 8, letterSpacing: '0.2em',
        textTransform: 'uppercase', color: PV2.brown, lineHeight: 1.8 }}>
        Sesión &middot; 8:21<br/>
        <span style={{ color: PV2.ink3 }}>Marina Tula</span>
      </div>
    </aside>
  );

  const topbar = (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '26px 40px', borderBottom: `0.5px solid ${PV2.border}`,
    }}>
      <div>
        <div style={{ fontFamily: PV2.sans, fontSize: 8, letterSpacing: '0.28em',
          textTransform: 'uppercase', color: PV2.brown,
          display: 'inline-flex', alignItems: 'center', gap: 12 }}>
          <span style={{ width: 24, height: 0.5, background: PV2.red }}/>
          Panel principal
        </div>
        <h1 style={{ fontFamily: PV2.serif, fontStyle: 'italic',
          fontSize: 36, lineHeight: 1.0, margin: '14px 0 0',
          fontWeight: 400, letterSpacing: '-0.025em', color: PV2.ink }}>
          Buen día, Marina.</h1>
      </div>
      <div style={{ display: 'flex', gap: 12 }}>
        <button className="btn-outline-red">Exportar CSV</button>
        <button className="btn-red">＋ Nueva estatua</button>
      </div>
    </div>
  );

  const metrics = [
    { n: '02',    lbl: 'Estatuas',  delta: '+1 este mes' },
    { n: '42',    lbl: 'Imágenes',  delta: '+12 este mes' },
    { n: '04',    lbl: 'Lugares',   delta: 'sin cambios' },
    { n: '3,418', lbl: 'Visitas QR',delta: '+18% vs julio' },
  ];

  const metricsBlock = (
    <div style={{
      display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0,
      borderBottom: `0.5px solid ${PV2.border}`,
    }}>
      {metrics.map((m, i) => (
        <div key={i} style={{
          padding: '36px 40px 36px',
          borderRight: (i % 2 === 0) ? `0.5px solid ${PV2.border}` : 'none',
          borderBottom: i < 2 ? `0.5px solid ${PV2.border}` : 'none',
        }}>
          <div style={{ fontFamily: PV2.sans, fontSize: 8, letterSpacing: '0.28em',
            textTransform: 'uppercase', color: PV2.brown, marginBottom: 18,
            display: 'inline-flex', alignItems: 'center', gap: 10 }}>
            <span style={{ width: 16, height: 0.5, background: PV2.red }}/>
            {m.lbl}
          </div>
          <div style={{ fontFamily: PV2.serif, fontStyle: 'italic',
            fontSize: 64, lineHeight: 1.0, color: PV2.red, fontWeight: 400,
            letterSpacing: '-0.02em' }}>{m.n}</div>
          <div style={{ fontFamily: PV2.sans, fontSize: 10, color: PV2.ink4,
            marginTop: 14, letterSpacing: '0.05em' }}>{m.delta}</div>
        </div>
      ))}
    </div>
  );

  const rows = [
    { num: 'I',  name: 'Cura Brochero', cat: 'Santo de los Caminos',
      stat: 'Activa', qr: '214', caps: 4, updated: 'Hace 2 días' },
    { num: 'II', name: 'San Lorenzo',   cat: 'Patrono del Pueblo',
      stat: 'Activa', qr: '178', caps: 4, updated: 'Hace 8 días' },
  ];

  const table = (
    <section style={{ padding: '40px 40px 48px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between',
        alignItems: 'baseline', marginBottom: 28 }}>
        <div>
          <div style={{ fontFamily: PV2.sans, fontSize: 8, letterSpacing: '0.28em',
            textTransform: 'uppercase', color: PV2.brown, marginBottom: 14,
            display: 'inline-flex', alignItems: 'center', gap: 10 }}>
            <span style={{ width: 24, height: 0.5, background: PV2.red }}/>
            Las estatuas del pueblo
          </div>
          <h2 style={{ fontFamily: PV2.serif, fontStyle: 'italic',
            fontSize: 28, margin: 0, fontWeight: 400, color: PV2.ink,
            letterSpacing: '-0.02em' }}>Catálogo &middot; /02 fichas</h2>
        </div>
        <div style={{ display: 'flex', gap: 18, fontFamily: PV2.sans, fontSize: 8,
          letterSpacing: '0.28em', textTransform: 'uppercase', color: PV2.brown }}>
          <span style={{ color: PV2.red, paddingBottom: 4,
            borderBottom: `0.5px solid ${PV2.red}` }}>Todas</span>
          <span>Activas</span>
          <span>Borrador</span>
        </div>
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ borderBottom: `0.5px solid ${PV2.border}`,
            borderTop: `0.5px solid ${PV2.border}` }}>
            {['', 'Estatua', 'Subtítulo', 'Capítulos', 'Visitas QR',
              'Última edición', 'Estado', 'Acciones'].map((h, i) => (
              <th key={i} style={{
                textAlign: 'left', padding: '14px 8px',
                fontFamily: PV2.sans, fontSize: 8, letterSpacing: '0.28em',
                textTransform: 'uppercase', color: PV2.brown, fontWeight: 500,
              }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} style={{ borderBottom: `0.5px solid ${PV2.border}` }}>
              <td style={{ padding: '22px 8px', fontFamily: PV2.serif,
                fontStyle: 'italic', fontSize: 16, color: PV2.red, width: 32 }}>/{r.num}</td>
              <td style={{ padding: '22px 8px' }}>
                <div style={{ fontFamily: PV2.serif, fontStyle: 'italic',
                  fontSize: 20, color: PV2.ink }}>{r.name}</div>
              </td>
              <td style={{ padding: '22px 8px', fontFamily: PV2.sans, fontSize: 11, color: PV2.ink3 }}>{r.cat}</td>
              <td style={{ padding: '22px 8px', fontFamily: PV2.serif,
                fontStyle: 'italic', fontSize: 18, color: PV2.ink }}>{r.caps}</td>
              <td style={{ padding: '22px 8px', fontFamily: PV2.serif,
                fontStyle: 'italic', fontSize: 18, color: PV2.ink }}>{r.qr}</td>
              <td style={{ padding: '22px 8px', fontFamily: PV2.sans, fontSize: 10,
                color: PV2.ink4, letterSpacing: '0.05em' }}>{r.updated}</td>
              <td style={{ padding: '22px 8px' }}>
                <span style={{
                  display: 'inline-flex', alignItems: 'center', gap: 8,
                  fontFamily: PV2.sans, fontSize: 8, letterSpacing: '0.28em',
                  textTransform: 'uppercase', color: PV2.red, fontWeight: 500,
                }}>
                  <span style={{ width: 5, height: 5, background: PV2.red }}/>
                  {r.stat}
                </span>
              </td>
              <td style={{ padding: '22px 8px' }}>
                <span style={{ fontFamily: PV2.sans, fontSize: 9,
                  letterSpacing: '0.22em', textTransform: 'uppercase',
                  color: PV2.brown, marginRight: 16 }}>Editar</span>
                <span style={{ fontFamily: PV2.sans, fontSize: 9,
                  letterSpacing: '0.22em', textTransform: 'uppercase',
                  color: PV2.ink4 }}>Archivar</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );

  return (
    <div style={{
      width: 1000, height: 760, background: PV2.bg, color: PV2.ink,
      fontFamily: PV2.sans, position: 'relative', overflow: 'hidden',
    }}
    className="paper-bg">
      {sidebar}
      <main style={{ marginLeft: 220, height: '100%', overflow: 'hidden' }}>
        {topbar}
        {metricsBlock}
        {table}
      </main>
    </div>
  );
}

window.AdminV2 = AdminV2;
