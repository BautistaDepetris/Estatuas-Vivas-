/* global React */
// Estatuas Vivas v2 — primitives en estilo crema/museo

const PV2 = {
  bg: '#F5EDD8', bg2: '#EDE0C4', bg3: '#E8D9B8', paper: '#FAF4E2',
  red: '#8B2020', redDark: '#6B1818', redLight: '#B14040',
  brown: '#6B4C2A', brownDark: '#3D2A14', brownSoft: '#8C6B42',
  ink: '#1C1008', ink2: '#3D2A14', ink3: '#6B4C2A', ink4: '#8C6B42',
  border: '#C4A882', borderDark: '#8C6B42',
  serif: `'Playfair Display', Georgia, serif`,
  sans: `'Inter', system-ui, sans-serif`,
};

// Paper-textured cream painting placeholder. Renders a soft oil-painting look.
function PaintingPh({ width = '100%', height = 200, label = 'Ilustración', tone = 'sepia', children, style = {} }) {
  const palettes = {
    sepia:   ['#a08768', '#6b4c2a', '#3d2a14'],
    pastoral:['#8b9b6b', '#5a6b3f', '#3d2a14'],
    portrait:['#b89572', '#7a5a3e', '#3d2a14'],
    sky:     ['#9bb0c8', '#6b8094', '#3d4a5c'],
    ember:   ['#b16040', '#8b3020', '#3d1010'],
  };
  const [c1, c2, c3] = palettes[tone] || palettes.sepia;
  return (
    <div style={{
      width, height, position: 'relative', overflow: 'hidden',
      background: `
        radial-gradient(ellipse at 40% 30%, ${c1} 0%, transparent 55%),
        radial-gradient(ellipse at 70% 70%, ${c3} 0%, transparent 60%),
        linear-gradient(160deg, ${c2} 0%, ${c3} 100%)
      `,
      ...style,
    }}>
      {/* canvas grain */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `
          radial-gradient(rgba(255,235,200,0.06) 1px, transparent 1px),
          radial-gradient(rgba(0,0,0,0.08) 1px, transparent 1px)
        `,
        backgroundSize: '5px 5px, 9px 9px',
        backgroundPosition: '0 0, 2px 3px',
        pointerEvents: 'none',
      }}/>
      {/* tiny inscription label, like a painting plate */}
      {label && (
        <div style={{
          position: 'absolute', bottom: 8, right: 10,
          fontFamily: PV2.sans, fontSize: 7, letterSpacing: '0.25em',
          textTransform: 'uppercase', color: 'rgba(245,237,216,0.55)',
          fontStyle: 'italic',
        }}>
          [ {label} ]
        </div>
      )}
      {children}
    </div>
  );
}

// Gold-frame painting (like the wall of paintings in the reference)
function FramedPainting({ width = 90, height = 100, tone = 'sepia', label, kicker, year }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
      <div style={{
        padding: 5,
        background: 'linear-gradient(135deg, #d9bf8a 0%, #b89c64 50%, #8c6b42 100%)',
        border: '0.5px solid #6b4c2a',
        boxShadow: '0 1px 2px rgba(60,40,20,0.25), inset 0 0 0 1px rgba(255,240,200,0.35)',
      }}>
        <PaintingPh width={width} height={height} tone={tone} label={null}/>
      </div>
      {label && (
        <div style={{ textAlign: 'center', maxWidth: width + 20 }}>
          {kicker && <div style={{ fontFamily: PV2.sans, fontSize: 7,
            letterSpacing: '0.1em', color: PV2.brown, marginBottom: 3 }}>{kicker}</div>}
          <div style={{ fontFamily: PV2.sans, fontSize: 8,
            color: PV2.ink2, lineHeight: 1.35 }}>{label}</div>
          {year && <div style={{ fontFamily: PV2.serif, fontSize: 8, fontStyle: 'italic',
            color: PV2.red, marginTop: 3 }}>{year}</div>}
        </div>
      )}
    </div>
  );
}

// Editorial /NN label with brown small label after
function EditorialNum({ num, label, color = PV2.red }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 14 }}>
      <span style={{ fontFamily: PV2.serif, fontStyle: 'italic', fontSize: 18,
        color, fontWeight: 400, letterSpacing: '-0.02em' }}>/{num}</span>
      <span style={{ fontFamily: PV2.sans, fontSize: 9, fontWeight: 500,
        letterSpacing: '0.28em', textTransform: 'uppercase', color: PV2.brown }}>{label}</span>
    </div>
  );
}

// Decorative thin brown line
function HrBrown({ width = '100%', color = PV2.border, thickness = 0.5, style = {} }) {
  return <div style={{ width, height: thickness, background: color, ...style }}/>;
}

// "Pueblo recomienda" handwritten-feel section header
function ScriptHeader({ children, color = PV2.ink, italic = true, size = 56 }) {
  return (
    <h2 style={{
      fontFamily: PV2.serif, fontStyle: italic ? 'italic' : 'normal',
      fontSize: size, fontWeight: 400, letterSpacing: '-0.02em',
      lineHeight: 0.95, color, margin: 0,
    }}>{children}</h2>
  );
}

// Status bar — light theme version
function StatusBarLight() {
  return (
    <div style={{
      height: 38, padding: '0 22px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontFamily: PV2.sans, fontSize: 13, fontWeight: 600, color: PV2.ink,
      position: 'relative', zIndex: 10,
    }}>
      <span>8:21</span>
      <span style={{ display: 'inline-flex', gap: 5, alignItems: 'center' }}>
        <span style={{ display:'inline-flex', gap: 1.5 }}>
          {[3,5,7,9].map((h,i) => <span key={i} style={{ width: 2.5, height: h, background: PV2.ink }}/>)}
        </span>
        <svg width="13" height="13" viewBox="0 0 24 24" fill={PV2.ink}><path d="M12 18.5l3-3a4.2 4.2 0 0 0-6 0l3 3zm0-6.2c2 0 3.9.8 5.3 2.2l1.4-1.4a9.5 9.5 0 0 0-13.4 0l1.4 1.4a7.5 7.5 0 0 1 5.3-2.2zm0-4a13 13 0 0 1 9.2 3.8l1.4-1.4A15 15 0 0 0 12 6.3a15 15 0 0 0-10.6 4.4l1.4 1.4A13 13 0 0 1 12 8.3z"/></svg>
        <span style={{ display:'inline-flex', alignItems:'center', gap: 1 }}>
          <span style={{ width: 22, height: 11, border: `1px solid ${PV2.ink}`, borderRadius: 2,
            padding: 1, boxSizing: 'border-box', display: 'flex' }}>
            <span style={{ flex: 1, background: PV2.ink, borderRadius: 1 }}/>
          </span>
          <span style={{ width: 1.5, height: 4, background: PV2.ink }}/>
        </span>
      </span>
    </div>
  );
}

// Little butterfly ornament (SVG)
function Butterfly({ size = 16, color = PV2.brown, style = {} }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color}
      strokeWidth="0.7" style={style}>
      <path d="M12 14c-1-3-3-5-5-5-1.5 0-3 1-3 3 0 2 2 4 4 4 1.5 0 3-1 4-2zM12 14c1-3 3-5 5-5 1.5 0 3 1 3 3 0 2-2 4-4 4-1.5 0-3-1-4-2zM12 7v12" />
    </svg>
  );
}

Object.assign(window, {
  PV2, PaintingPh, FramedPainting, EditorialNum, HrBrown, ScriptHeader,
  StatusBarLight, Butterfly,
});
