# UI Kit · Móvil — Estatuas Vivas

Las 5 pantallas que componen Villa San Lorenzo, presentadas lado a lado en un canvas pan/zoom.

## Pantallas

| # | Pantalla            | Ancho | Función |
|---|---------------------|-------|--------|
| 01 | Home                | 390   | Landing del pueblo, índice de las estatuas |
| 02 | Página de estatua   | 390   | **La más importante** — se abre al escanear el QR |
| 03 | Galería completa    | 390   | Masonry de archivo histórico, con filtros |
| 04 | Lugares             | 390   | Recorrido curado del pueblo |
| 05 | Dashboard admin     | 1000  | Panel interno del equipo |

Las pantallas viven en `prototype/` (`HomeV2.jsx`, `EstatuaV2.jsx`, `Screens.jsx`) para evitar duplicación; este UI Kit las referencia con paths relativos.

## Componentes reutilizables

Exportados a `window` desde `prototype/components.jsx`:

| Componente | Uso |
|---|---|
| `PV2` | Objeto con todos los tokens (colores + fuentes) |
| `<PaintingPh tone="sepia">` | Placeholder de imagen estilo óleo (5 tonos) |
| `<FramedPainting>` | Pintura con marco dorado completo |
| `<EditorialNum num="01" label="Las Estatuas"/>` | Header de sección /NN |
| `<HrBrown>` | Hairline marrón |
| `<ScriptHeader>` | Título Playfair italic |
| `<StatusBarLight>` | Barra de estado mobile clara |
| `<Butterfly>` | Mariposa SVG decorativa |

## Cómo navegar el canvas

- **Trackpad / scroll**: pan
- **Pinch / Ctrl+scroll**: zoom
- **Click sobre artboard**: focus mode (pantalla completa)
- **← → Esc**: navegar entre artboards en focus
