# Handoff — Estatuas Vivas · Villa San Lorenzo

> Plataforma de turismo cultural digital para Villa San Lorenzo (Córdoba, Argentina). Las estatuas del pueblo llevan un QR; al escanearlo, el visitante abre la historia del prócer.

---

## 1. Cómo usar este paquete

**Los archivos HTML/JSX dentro de `prototype/`, `ui_kits/` y `preview/` son referencias visuales, NO código de producción.** Fueron creados en HTML + React-via-Babel para iterar diseño rápido. Tu tarea es **recrearlos en tu codebase Next.js usando los patrones que ya tenés** (App Router, Tailwind 4, Server/Client Components, Supabase).

Si necesitás ver un componente, copy o estado: abrí el HTML correspondiente en el navegador y leelo como spec visual.

### Stack objetivo (ya existente)

| | |
|---|---|
| Framework | Next.js 16 App Router |
| Lenguaje  | TypeScript |
| Estilos   | Tailwind 4 (con `@theme`) + estilos inline donde haga falta |
| Datos     | Supabase si hay env vars, si no `src/lib/data/estatuas-mock.ts` |
| Rutas públicas  | `/`, `/estatuas/[slug]` |
| Rutas admin     | `/admin`, `/admin/estatuas`, `/admin/galeria`, `/admin/lugares` |

Ver `reference/project-context.json` para el detalle completo del codebase real (componentes legacy, mocks, schema de Supabase).

---

## 2. Fidelidad

**Hi-fi.** Colores, tipografía, espaciado, jerarquía e interacciones están definidos a nivel pixel. El dev debe reproducir el diseño 1:1 usando Tailwind utilities (`@theme` ya configurado abajo) o estilos inline donde Tailwind no llegue.

---

## 3. Tokens — copiar a `src/app/globals.css`

Reemplazá el bloque `@theme` actual (que tiene colores oscuros/dorados) por este:

```css
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500;1,600;1,700;1,800&family=Inter:wght@300;400;500;600;700&display=swap');

@theme {
  /* Surfaces */
  --color-bg:        #F5EDD8;
  --color-bg-2:      #EDE0C4;
  --color-bg-3:      #E8D9B8;
  --color-paper:     #FAF4E2;

  /* Accent — único acento */
  --color-rojo:      #8B2020;
  --color-rojo-dark: #6B1818;
  --color-rojo-light:#B14040;

  /* Earth / text */
  --color-ink:       #1C1008;
  --color-ink-2:     #3D2A14;
  --color-brown:     #6B4C2A;
  --color-brown-soft:#8C6B42;
  --color-border:    #C4A882;

  /* Type */
  --font-serif:      var(--font-playfair), 'Playfair Display', Georgia, serif;
  --font-sans:       var(--font-inter), 'Inter', system-ui, sans-serif;
}

html, body { background: var(--color-bg); color: var(--color-ink); }
```

El archivo `colors_and_type.css` adjunto tiene la versión completa (incluye `.btn-red`, `.frame`, `.paper-bg`, etc.).

### Fuentes

Ya tenés `next/font/google` configurado. Asegurate de cargar:
- `Playfair Display` italic 400 (mínimo), idealmente también 500/600/700 italic.
- `Inter` 300, 400, 500, 600, 700.

```ts
// src/app/layout.tsx
import { Playfair_Display, Inter } from 'next/font/google';
const playfair = Playfair_Display({
  subsets: ['latin'], style: ['normal', 'italic'],
  weight: ['400','500','600','700'],
  variable: '--font-playfair',
});
```

---

## 4. Sistema visual — reglas no negociables

Estas reglas son **lo que diferencia este diseño del look anterior dark/gold**. Si alguna se rompe, el diseño deja de ser este sistema.

1. **Playfair siempre italic** para títulos. Un Playfair recto está fuera del sistema.
2. **Bordes siempre 0.5px**. Nunca 1px ni 2px. Única excepción: el borde-top del audio player (1px rojo).
3. **Radio 0 en todo**. Cards, inputs, botones. Excepción única: `.btn-play` circular (50%).
4. **Un solo acento: rojo `#8B2020`**. Nada de azul info, verde success, amarillo warning. El éxito y el error van también en rojo.
5. **Imágenes siempre dentro de un marco dorado-marrón** (`linear-gradient(135deg, #d9bf8a, #b89c64 60%, #8c6b42)`, padding 5px, border 0.5px solid `#6b4c2a`). Ver `.frame` en `colors_and_type.css`.
6. **Numerales editoriales**: `/01 /02 /03` para secciones, `/I /II /III /IV` para capítulos. Siempre Playfair italic rojo.
7. **Etiquetas micro**: Inter 9px, uppercase, `letter-spacing: 0.28em` (sí, 0.28 — no 0.1), color marrón. Suelen ir precedidas de una línea roja de 0.5px y 24px de ancho.
8. **Sin emoji. Nunca.**

---

## 5. Pantallas — mapeo a rutas

Cada pantalla corresponde a una ruta del codebase real. La pantalla está completamente diseñada en el archivo HTML/JSX indicado.

| Ruta | Pantalla diseñada | Archivo de referencia |
|---|---|---|
| `/` | Home | `prototype/HomeV2.jsx` |
| `/estatuas/[slug]` | Página de estatua (Brochero, San Lorenzo) | `prototype/EstatuaV2.jsx` |
| `/estatuas/[slug]` (sección Galería) | Galería completa | `prototype/Screens.jsx` → `GaleriaV2` |
| `/lugares` o sección Home | Lugares para conocer | `prototype/Screens.jsx` → `LugaresV2` |
| `/admin` | Dashboard admin | `prototype/Screens.jsx` → `AdminV2` |

### 5.1 — `/` Home

**Layout:** mobile-first, ancho 390–412. Cinco secciones verticales separadas por bandas alternas de `--bg` y `--bg-2`.

| Sección | Detalle |
|---|---|
| **Hero** | Wordmark italic chiquito arriba-izq + 3 puntos rojos arriba-der. Título principal `Las Estatuas Cobran Vida.` en Playfair italic 62px ink, con una pintura enmarcada incrustada DENTRO del título entre "Cobran" y "Vida." (size 72×54, tone="portrait"). Subtítulo de label uppercase debajo. CTA `.btn-red` `Explorar el pueblo →`. Mariposa decorativa esquina superior derecha. Fondo `.paper-bg`. |
| **/01 Las Estatuas** | Header `/01 ──── LAS ESTATUAS`. Título italic `Dos figuras, dos siglos.` (36px). Dos cards verticales una abajo de la otra: pintura enmarcada altura 240, kicker uppercase marrón ("Santo de los Caminos" / "Patrono del Pueblo"), título italic rojo 30px, descripción Inter 11px ink-3, CTA "Descubrir →". Cards clickeables → `/estatuas/cura-brochero` y `/estatuas/san-lorenzo`. |
| **/02 Galería Histórica** | Fondo `--bg-2`. Header /02. Grid 2 columnas con 4 cards de pintura altura 140. Kicker + título italic. Botón `.btn-outline-red` `Ver galería completa →`. |
| **/03 Lugares para Conocer** | Header /03. Lista de 4 lugares (Capilla Brochero, Iglesia San Lorenzo, Plaza Central, Sendero de las Sierras). Cada item: thumb cuadrado 62×62 enmarcado a la izquierda + kicker + título italic 16px + descripción + flecha roja a la derecha. Separadas por hairline 0.5px. |
| **Footer** | Hairline marrón arriba. Wordmark italic rojo 30px. Label "PATRIMONIO CULTURAL DIGITAL · CÓRDOBA". Nav: ESTATUAS / GALERÍA / LUGARES / ADMIN. Copyright italic. |

### 5.2 — `/estatuas/[slug]` Página de estatua

La pantalla más importante. **Slugs activos: `cura-brochero`, `san-lorenzo`**.

| Sección | Detalle |
|---|---|
| **Hero** | Altura 720. Pintura full-bleed tone="portrait" (o el que corresponda al prócer) con overlay crema 50% al pie. Status bar mobile. Botón X arriba-derecha (`/estatuas/[slug]` → `/`). En el centro, un placeholder marcado `[ Video — Cura Brochero ]` con borde dashed rojo: **acá va el video animado del prócer (a generar con IA)**. Abajo-izq: kicker "Santo de los Caminos", título italic rojo 64px "Cura Brochero" (dos líneas), subtítulo "1840 — 1914 · Santa Rosa, Córdoba". Mariposa decorativa. |
| **/01 Su Historia** | Header. Subtítulo italic "Cuatro capítulos de una vida." Carrusel horizontal scroll de cards con capítulos /I /II /III /IV. Cada card: 240×auto, fondo `--bg-2`, borde 0.5px, padding 22. Numeral italic rojo "/I" + título italic 18px + texto 11px ink-3 line-height 1.75. Indicador de dots abajo (primer dot rojo 16px ancho, resto 4px marrón). |
| **/02 Frase destacada** | Banda `--bg-2`. Comillas `"` Playfair 92px rojo opacity 18%. Hairlines marrón 50px arriba y abajo. Frase italic 22px center. Atribución uppercase marrón. Mariposa decorativa esquina. |
| **/03 Galería** | Header. Carrusel horizontal de 4 imágenes enmarcadas 220×270 con kicker + título + descripción debajo. |
| **/04 El Pueblo Recomienda** | Banda `--bg-2`. Header. Quote italic "Si querés conocer mis pasos, te dejo estos lugares —". Lista de 2 lugares (los del array `lugares` del modelo Estatua) con thumb enmarcado 56×56. |
| **/05 Siguiente estatua** | Altura 200. Pintura tone="ember" full-bleed con overlay crema. Kicker "Continuá el recorrido", título italic rojo 32px con la siguiente estatua. Link a `getSiguienteEstatua(slug)`. |
| **AudioPlayer flotante** | Fixed bottom. Altura 64. Fondo `--bg-2`. Border-top `1px solid var(--rojo)` (**única excepción a la regla 0.5px**). Ícono música rojo 16px, track label uppercase, barra 1px (track marrón, fill rojo 35%), tiempos en ink-4, botón play circular rojo 38×38. Si `audio_url === null`, mostrar "Audio próximamente". |

### 5.3 — `/admin` Dashboard

Desktop 1000 wide. Layout: sidebar fijo 220px crema (`--bg-2`) + main.

| Elemento | Detalle |
|---|---|
| Sidebar | Wordmark italic rojo "San Lorenzo" arriba + label "ADMIN". Nav links uppercase 9px tracking 0.28em. Item activo: `--rojo`, borde izq 2px rojo. Items: Dashboard, Estatuas (/02), Galería (/42), Lugares (/04). Conteo italic Playfair pequeño a la derecha. Footer con sesión. |
| Topbar | Border-bottom 0.5px. Eyebrow "/ PANEL PRINCIPAL". H1 italic 36px "Buen día, Marina." Botones `.btn-outline-red` + `.btn-red`. |
| Métricas | Grid 2×2 con hairlines internas. Cada celda: eyebrow + numeral italic rojo 64px + delta en ink-4. |
| Tabla | Header eyebrow "/ LAS ESTATUAS DEL PUEBLO" + H2 italic "Catálogo · /02 fichas" + tabs Todas/Activas/Borrador. Columnas: /, Estatua (italic 20), Subtítulo (Inter 11), Capítulos (italic 18), Visitas QR (italic 18), Última edición (Inter 10), Estado (chip rojo con dot), Acciones (Editar / Archivar). |

---

## 6. Reescribir componentes legacy

Los siguientes componentes existen en tu codebase pero están en el look oscuro/dorado viejo. Hay que reescribirlos en el sistema crema. Todos viven en `src/components/estatua/` salvo aclaración.

| Archivo | Estado | Acción |
|---|---|---|
| `AudioPlayer.tsx` | En uso | Reescribir con `border-top: 1px solid var(--color-rojo)`, fondo `--bg-2`, botón play rojo. Mantener la lógica de play/pause/seek. |
| `HeroSection.tsx` | Legacy, no importado | Reescribir según sección 5.2 Hero. Reemplazar el gradiente negro por la pintura enmarcada + overlay crema. **Incluir el placeholder del video del prócer**. Importar desde `app/estatuas/[slug]/page.tsx`. |
| `QuoteCard.tsx` | Legacy, no importado | Reescribir según sección 5.2 /02 Frase destacada. Comillas Playfair 92px rojo opacity 18%. |
| `ImageGallery.tsx` | Legacy, no importado | Reescribir según sección 5.2 /03 Galería. Carrusel horizontal con `overflow-x-auto scroll-snap`. Modal/lightbox al hacer click. |
| `NextStatuaButton.tsx` | Legacy, no importado | Reescribir según sección 5.2 /05 Siguiente estatua. Pintura tone="ember" + overlay. |
| `LoadingSpinner.tsx` | No importado | Reescribir: spinner rojo simple sobre fondo crema. Estilo discreto, sin neon. |

### Componentes nuevos a crear

| Nombre sugerido | Para qué |
|---|---|
| `EditorialNum.tsx` | El header `/01 ──── LAS ESTATUAS`. Recibe `num` y `label`. |
| `FramedPainting.tsx` | Wrapper que aplica `.frame` (gradiente dorado + padding 5 + border). Recibe `children` (la `<Image>` real de next/image). |
| `EstatuaCard.tsx` | Card editorial del Home con kicker + título italic + descripción + CTA. Link a `/estatuas/[slug]`. |
| `LugarRow.tsx` | Fila de lugar con thumb cuadrado enmarcado + kicker + título + flecha. |
| `Butterfly.tsx` | SVG inline de mariposa decorativa (ver `assets/butterfly.svg`). Usar a discreción, una por sección máximo. |

### Reemplazar placeholders

El prototipo usa `<PaintingPh tone="...">` para placeholders. En producción reemplazar por `next/image` con la imagen real del array `imagenes` de la estatua, **siempre dentro de un `<FramedPainting>`**. Mientras no haya foto final, mantener el placeholder oscuro con grano + overlay tone-según-prócer.

---

## 7. Datos — fuentes y mocks

Usar lo que ya está:

- `src/lib/data/estatuas-mock.ts` tiene los datos completos de Brochero y San Lorenzo (capítulos, frase, imágenes, lugares).
- `src/lib/supabase/queries.ts` ya tiene fallback a mocks si no hay Supabase configurado.
- **No hardcodear textos en los componentes.** Todo viene del modelo `Estatua` (ver `src/types/index.ts`).

Datos clave (por si los necesitás verificar):

| Slug | Nombre | Subtítulo | Visitas | Frase |
|---|---|---|---|---|
| `cura-brochero` | Cura Brochero | Santo de los Caminos · 1840–1914 | 214 | _La religión no se predica, se vive._ |
| `san-lorenzo` | San Lorenzo | Patrono del Pueblo · Mártir Romano | 178 | _Dame la gracia de saber sufrir._ |

Capítulos de Brochero: I — Sus Orígenes / II — Los Caminos de las Sierras / III — El Hombre del Pueblo / IV — Su Legado.
Capítulos de San Lorenzo: I — El Imperio Romano / II — El Diácono Valiente / III — El Martirio / IV — Su Nombre en el Pueblo.

---

## 8. Interacciones

| Trigger | Comportamiento |
|---|---|
| Click en estatua-card del Home | Navegar a `/estatuas/[slug]` |
| Click en X de la página de estatua | Volver a `/` |
| Click en "Siguiente estatua" del pie | Navegar a `/estatuas/[siguiente.slug]` (usar `getSiguienteEstatua`) |
| Click en botón play del AudioPlayer | Toggle play/pause sobre `<audio>` |
| Scroll horizontal en /01 Su Historia | Pan nativo (`overflow-x: auto`), sin botones |
| Hover sobre card | Sin transformación; sólo el borde marrón se oscurece sutilmente |
| Hover sobre `.btn-red` | Fondo cambia a `--rojo-dark` |
| Focus en `.input` | Borde cambia a `--rojo` |
| Visita a `/estatuas/[slug]` | `VisitaTracker` dispara `incrementarVisitas(slug)` en `useEffect` |

**Animaciones:**
- Transición de página: 300ms `ease-out`.
- Hover: 150ms `ease-out`.
- Sin springs, sin bounces, sin parallax.

---

## 9. Estados especiales

| Estado | Diseño |
|---|---|
| Loading (estatua sin cargar) | Spinner rojo + label "Cargando..." en italic ink-3 |
| Error (estatua no encontrada) | Página simple: H1 italic "No encontramos esa estatua." + link a `/` |
| Audio inexistente | AudioPlayer renderiza igual pero con texto "Audio próximamente" donde iría el título de track. Ocultar el play. |
| Galería vacía | Mostrar sección con quote italic ink-4: "Aún no tenemos imágenes para esta estatua." |
| Lugares vacíos | Misma estrategia que galería. |

---

## 10. Responsive

Mobile-first. La app está pensada para 390–412px. Para tablet y desktop:
- Hero crece a max 640px de ancho centrado.
- Grid de 2 columnas pasa a 3 a partir de 768px.
- Admin dashboard ya es desktop puro.

---

## 11. Assets

Todo en `assets/`:

| Archivo | Uso |
|---|---|
| `wordmark.svg` | Wordmark italic rojo. Header de pantallas claras. |
| `wordmark-cream.svg` | Wordmark italic crema. Para fondos rojos (raros — solo CTAs grandes). |
| `monogram.svg` | "VSL" italic. Favicon. |
| `butterfly.svg` | Mariposa decorativa. Una por sección máximo. |
| `ornament.svg` | Línea con flourish central. Separador opcional de capítulos. |

### Imágenes finales

**Pendiente:** todavía no se entregaron las fotografías reales del archivo histórico, ni el video animado del prócer. Mientras tanto, los placeholders cumplen su rol visual. Cuando lleguen:
- Las fotos van **siempre** dentro de `<FramedPainting>` (no romper el marco dorado).
- El video del prócer reemplaza el placeholder dashed del hero de estatua (sección 5.2).

---

## 12. Archivos en este paquete

```
design_handoff_estatuas_vivas/
├── README.md                   ← este archivo
├── colors_and_type.css         ← tokens completos del sistema
├── assets/                     ← SVGs de marca
├── prototype/                  ← prototipo clickeable end-to-end
│   ├── index.html              ← abrir en navegador para ver el flujo
│   ├── components.jsx          ← primitives (PaintingPh, EditorialNum, etc.)
│   ├── HomeV2.jsx              ← Home spec
│   ├── EstatuaV2.jsx           ← Estatua spec
│   ├── Screens.jsx             ← Galería, Lugares, Admin spec
│   └── tokens.css              ← tokens duplicados (usar colors_and_type.css)
├── ui_kits/mobile/
│   ├── index.html              ← las 5 pantallas lado a lado
│   ├── README.md
│   └── design-canvas.jsx
├── preview/                    ← 21 cards del Design System (referencia visual)
│   ├── brand-*.html            ← marca, voz
│   ├── color-*.html            ← paleta
│   ├── type-*.html             ← tipografía
│   ├── spacing-*.html          ← spacing, bordes, radios
│   └── component-*.html        ← componentes
└── reference/
    ├── imagen-museo-referencia.jpg  ← la inspiración visual
    └── project-context.json         ← estructura completa del codebase real
```

### Cómo recorrer el paquete

1. Leé este README completo.
2. Abrí `prototype/index.html` en un navegador para clickear el flujo end-to-end.
3. Abrí `ui_kits/mobile/index.html` para ver las 5 pantallas lado a lado a escala.
4. Cuando tengas dudas de un componente puntual, abrí la card correspondiente en `preview/`.
5. Si necesitás verificar datos o estructura del codebase real, mirá `reference/project-context.json`.

---

## 13. Checklist de implementación

- [ ] Migrar `@theme` en `globals.css` a los tokens crema.
- [ ] Configurar `Playfair_Display` italic + `Inter` en `next/font/google`.
- [ ] Reescribir `AudioPlayer.tsx` al estilo crema.
- [ ] Crear `FramedPainting.tsx` y `EditorialNum.tsx`.
- [ ] Reescribir `app/page.tsx` (Home) con las 5 secciones.
- [ ] Reescribir `app/estatuas/[slug]/page.tsx` con las 6 secciones (incluido placeholder de video).
- [ ] Reescribir layout y páginas de `app/admin/*` con el sistema crema.
- [ ] Activar `HeroSection.tsx`, `QuoteCard.tsx`, `ImageGallery.tsx`, `NextStatuaButton.tsx` en lugar de los bloques inline actuales.
- [ ] Subir las fotografías reales y reemplazar `<PaintingPh>` por `<Image>` dentro de `<FramedPainting>`.
- [ ] Cuando estén los videos del prócer, embeber en el hero de estatua.
- [ ] Auditar: cero radios > 0px (salvo `.btn-play`), cero bordes > 0.5px (salvo audio player), cero emoji.

---

## 14. Soporte

Si quedan dudas, lo más fiable es abrir el archivo `.jsx` o `.html` correspondiente y leerlo como spec — está todo escrito en valores concretos (`fontSize: 26`, `letterSpacing: '0.28em'`, etc.), nada queda al criterio.
